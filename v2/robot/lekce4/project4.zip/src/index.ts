import * as colors from "./libs/colors.js"
import { SmartLed } from "smartled"
import { stdout } from "stdio"
import { createRobutek } from "./libs/robutek.js"
const robutek = createRobutek("V2");

// Tady si napište své řešení