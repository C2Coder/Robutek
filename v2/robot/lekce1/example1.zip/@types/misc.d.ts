/**
 * Exits the current program.
 * @param code The exit code to use.
 */
declare function exit(code?: number): void;
